// create-basic-zip.js
const fs = require('fs');
const archiver = require('archiver');

const folder = 'e-kubor-basic';
const output = fs.createWriteStream(`${folder}.zip`);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => console.log(`✅ ZIP siap: ${archive.pointer()} bytes dalam ${folder}.zip`));
archive.on('error', err => { throw err; });

archive.pipe(output);
archive.directory(folder + '/', false);
archive.finalize();
