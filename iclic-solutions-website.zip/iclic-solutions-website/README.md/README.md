# I CLIC SOLUTIONS Website

📄 Laman web statik versi Bahasa Melayu.

## Struktur Fail
- `index.html` – halaman utama
- `styles.css` – gaya laman
- `scripts.js` – fungsi tombol & borang
- `assets/logo.png` – logo placeholder

## Deploy ke GitHub Pages
1. Cipta repositori `iclic-solutions-website`
2. Upload semua fail
3. Pergi ke Settings → Pages
4. Pilih branch `main`, folder `/ (root)`
5. Simpan → tunggu link: `https://<username>.github.io/iclic-solutions-website/`
